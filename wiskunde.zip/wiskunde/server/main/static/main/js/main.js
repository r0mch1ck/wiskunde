let greet = () => console.log("Все понятно");
greet();